var localizedStrings = new Array;

localizedStrings["StartUpTxt"] = "Klicka här för att starta en tid.";

localizedStrings["clockClickToReset"] = "Klicka för att återgå.";
localizedStrings["null"] = "";
localizedStrings["custommsgtitle"] = "Larm meddelande:";
localizedStrings["timesupmessage"] = "Tiden är ute!";
    
localizedStrings["Laptime"] = "VARVTID";
localizedStrings["Start"] = "Starta";
localizedStrings["Stop"] = "Stoppa";
localizedStrings["Lap on"] = "Varv på";
localizedStrings["Lap off"] = "Varv av";
localizedStrings["Reset"] = "Återgå";

localizedStrings["textfieldstitle"] = "Räkna ner ifrån:";
localizedStrings["notificationstitle"] = "Meddelande:";
localizedStrings["labeltitle"] = "Etikett:";
localizedStrings["labelfieldinstructions"] = "Använd din egen etikett.";
localizedStrings["customMsgTextFieldTitleTag"] = "Skapa ditt egna larm meddelande.";
localizedStrings["bringtofront"] = "<span title='När Dashboard är gömt gör det aktivt.'>Visa först</span>";
localizedStrings["repeatcheckboxtext"] = "<span title='Repetera alarm ljudet tills det stoppas.'>Repetera ljud</span>";
localizedStrings["instructions"] = "Skriv in timmar, minuter och sekunder i rutorna, eller använd snabblistan nedan.";
localizedStrings["sndPopup"] = "Välj ett ljud alternativ från listan.";
localizedStrings["noSound"] = "Inget ljud";
localizedStrings["3-2-1 Bell"] = "3-2-1 Klocka";
localizedStrings["Done"] = "Klar";
localizedStrings["helpButtonTitleTag"] = "3-2-1 Hjälp";

localizedStrings["laptimeLabelCutOffPoint"] = 268;
localizedStrings["buttonLabelsCutOffPoint"] = 163;