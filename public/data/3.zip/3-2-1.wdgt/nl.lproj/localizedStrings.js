var localizedStrings = new Array;

localizedStrings["StartUpTxt"] = "Klik hier om een tijd in te stellen.";

localizedStrings["clockClickToReset"] = "Klik om te resetten.";
localizedStrings["null"] = "";
localizedStrings["custommsgtitle"] = "Mededeling:";
localizedStrings["timesupmessage"] = "Tijd is om!";
   
localizedStrings["Laptime"] = "KLOKKING";
localizedStrings["Start"] = "Start";
localizedStrings["Stop"] = "Stop";
localizedStrings["Lap on"] = "Klokken";
localizedStrings["Lap off"] = "Doorgaan";
localizedStrings["Reset"] = "Resetten";

localizedStrings["textfieldstitle"] = "Aftellen vanaf:";
localizedStrings["notificationstitle"] = "Meldingen:";
localizedStrings["labeltitle"] = "Etiket:";
localizedStrings["labelfieldinstructions"] = "Voer eigen titel in.";
localizedStrings["customMsgTextFieldTitleTag"] = "Voer uw eigen mededeling in.";
localizedStrings["bringtofront"] = "<span title='Blijf actief als Dashboard verborgen is.'>Breng naar voren</span>";
localizedStrings["repeatcheckboxtext"] = "<span title='Herhaal geluidseffect tot stopzetting.'>Herhaal geluid</span>";
localizedStrings["instructions"] = "Voer uren, minuten en seconden in de hokjes in of gebruik de snelmenu's onder.";
localizedStrings["sndPopup"] = "Kies een geluidseffect uit de lijst.";
localizedStrings["noSound"] = "Geen geluid";
localizedStrings["3-2-1 Bell"] = "3-2-1 Bel";
localizedStrings["Done"] = "Gereed";
localizedStrings["helpButtonTitleTag"] = "3-2-1 Help";

localizedStrings["laptimeLabelCutOffPoint"] = 292;
localizedStrings["buttonLabelsCutOffPoint"] = 172;
