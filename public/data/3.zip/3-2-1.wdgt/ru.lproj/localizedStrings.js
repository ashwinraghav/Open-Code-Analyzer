var localizedStrings = new Array;

localizedStrings["StartUpTxt"] = "Нажмите здесь чтобы настроить время.";

localizedStrings["clockClickToReset"] = "Нажмите для перезапуска.";
localizedStrings["null"] = "";
localizedStrings["custommsgtitle"] = "Сообщение уведомления:";
localizedStrings["timesupmessage"] = "Время прошло!";
  
localizedStrings["Laptime"] = "Время цикла";
localizedStrings["Start"] = "Начать";
localizedStrings["Stop"] = "Закончить";
localizedStrings["Lap on"] = "Цикл запущен";
localizedStrings["Lap off"] = "Цикл выключен";
localizedStrings["Reset"] = "Перезапуск";

localizedStrings["textfieldstitle"] = "Начать обратный отсчёт с:";
localizedStrings["notificationstitle"] = "Уведомление:";
localizedStrings["labeltitle"] = "Название:";
localizedStrings["labelfieldinstructions"] = "Введите своё название.";
localizedStrings["customMsgTextFieldTitleTag"] = "Введите своё уведомительное сообщение.";
localizedStrings["bringtofront"] = "<span title='Когда DashBoard закрыт, сделать этот виджет активной.'>Показать</span>";
localizedStrings["repeatcheckboxtext"] = "<span title='Повторять звук напоминания до остановки.'>Повторить звук</span>";
localizedStrings["instructions"] = "Введите часы, минуты и секунды в поля или выберите из предложенных снизу.";
localizedStrings["sndPopup"] = "Выбрать звук из списка.";
localizedStrings["noSound"] = "Беззвучно";
localizedStrings["3-2-1 Bell"] = "3-2-1 Звонок";
localizedStrings["Done"] = "Готово";
localizedStrings["helpButtonTitleTag"] = "Справка 3-2-1";

localizedStrings["laptimeLabelCutOffPoint"] = 356;
localizedStrings["buttonLabelsCutOffPoint"] = 200;