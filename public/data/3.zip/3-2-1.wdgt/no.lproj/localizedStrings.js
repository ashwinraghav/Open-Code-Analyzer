var localizedStrings = new Array;

localizedStrings["StartUpTxt"] = "Klikk her for å stille inn tiden.";

localizedStrings["clockClickToReset"] = "Klikk for å resette.";
localizedStrings["null"] = "";
localizedStrings["custommsgtitle"] = "Alarmmelding:";
localizedStrings["timesupmessage"] = "Tiden er ute!";

localizedStrings["Laptime"] = "RUNDETID";
localizedStrings["Start"] = "Start";
localizedStrings["Stop"] = "Stopp";
localizedStrings["Lap on"] = "Vis rundetid";
localizedStrings["Lap off"] = "Gjem rundetid";
localizedStrings["Reset"] = "Reset";

localizedStrings["textfieldstitle"] = "Tell ned fra:";
localizedStrings["notificationstitle"] = "Varsling:";
localizedStrings["labeltitle"] = "Merknad:";
localizedStrings["labelfieldinstructions"] = "Skriv inn din egen merknad.";
localizedStrings["customMsgTextFieldTitleTag"] = "Skriv inn din egen alarmmelding.";
localizedStrings["bringtofront"] = "<span title='Hent frem Dashboard når alarmen går.'>Hent frem</span>";
localizedStrings["repeatcheckboxtext"] = "<span title='Gjenta lyd inntil alarmen skrus av.'>Gjenta lyd</span>";
localizedStrings["instructions"] = "Skriv inn timer, minutter og sekunder i boksene, eller bruk hjelpelista under.";
localizedStrings["sndPopup"] = "Velg en lydinnstilling fra listen.";
localizedStrings["noSound"] = "Ingen lyd";
localizedStrings["3-2-1 Bell"] = "3-2-1 Klocka";
localizedStrings["Done"] = "Ferdig";
localizedStrings["helpButtonTitleTag"] = "3-2-1 Hjelp";

localizedStrings["laptimeLabelCutOffPoint"] = 316;
localizedStrings["buttonLabelsCutOffPoint"] = 195;