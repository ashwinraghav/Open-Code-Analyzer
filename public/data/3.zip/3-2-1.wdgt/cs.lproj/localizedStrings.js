var localizedStrings = new Array;

localizedStrings["StartUpTxt"] = "Klikněte pro nastavení.";

localizedStrings["clockClickToReset"] = "Klikněte pro vynulování.";
localizedStrings["null"] = "";
localizedStrings["custommsgtitle"] = "Text oznámení:";
localizedStrings["timesupmessage"] = "Čas vypršel!";
  
localizedStrings["Laptime"] = "Mezičas";
localizedStrings["Start"] = "Start";
localizedStrings["Stop"] = "Stop";
localizedStrings["Lap on"] = "Mezičas";
localizedStrings["Lap off"] = "Zrušit mezičas";
localizedStrings["Reset"] = "Vynulovat";

localizedStrings["textfieldstitle"] = "Odpočítávat od:";
localizedStrings["notificationstitle"] = "Oznámení:";
localizedStrings["labeltitle"] = "Popisek okna:";
localizedStrings["labelfieldinstructions"] = "Vepište svůj vlastní název okna.";
localizedStrings["customMsgTextFieldTitleTag"] = "Vepište svoje vlastní oznámení.";
localizedStrings["bringtofront"] = "<span title='Zobrazí Dashboard, pokud již není aktivní.'>Okno do popředí</span>";
localizedStrings["repeatcheckboxtext"] = "<span title='Opakovat výstražný zvuk až do vypnutí.'>Opakovat zvuk</span>";
localizedStrings["instructions"] = "Vepiště hodiny, minuty a sekundy do příslušných políček nebo si je vyberte ze seznamu.";
localizedStrings["sndPopup"] = "Vyberte zvuk ze seznamu.";
localizedStrings["noSound"] = "Beze zvuku";
localizedStrings["3-2-1 Bell"] = "3-2-1 Zvonek";
localizedStrings["Done"] = "Hotovo";
localizedStrings["helpButtonTitleTag"] = "3-2-1 Nápověda";

localizedStrings["laptimeLabelCutOffPoint"] = 290;
localizedStrings["buttonLabelsCutOffPoint"] = 195;