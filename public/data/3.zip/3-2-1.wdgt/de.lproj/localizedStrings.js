var localizedStrings = new Array;

localizedStrings["StartUpTxt"] = "Hier klicken um eine Zeit einzustellen.";

localizedStrings["clockClickToReset"] = "Hier klicken zum Zurücksetzen.";
localizedStrings["null"] = "";
localizedStrings["custommsgtitle"] = "Alarmmeldung:";
localizedStrings["timesupmessage"] = "Zeit abgelaufen!";

localizedStrings["Laptime"] = "RUNDENZEIT";
localizedStrings["Start"] = "Start";
localizedStrings["Stop"] = "Stop";
localizedStrings["Lap on"] = "Runde EIN";
localizedStrings["Lap off"] = "Runde AUS";
localizedStrings["Reset"] = "Zurücksetzen";

localizedStrings["textfieldstitle"] = "Zeiteinstellungen:";
localizedStrings["notificationstitle"] = "Mitteilungen:";
localizedStrings["labeltitle"] = "Bezeichnung:";
localizedStrings["labelfieldinstructions"] = "Geben Sie eine Bezeichnung ein.";
localizedStrings["customMsgTextFieldTitleTag"] = "Geben Sie Ihre eigene Alarmmeldung ein.";
localizedStrings["bringtofront"] = "<span title='Dashboard aktivieren falls unsichtbar.'>Nach vorne bringen</span>";
localizedStrings["repeatcheckboxtext"] = "<span title='Wiederholt den Alarmton bis zur Deaktivierung.'>Ton wiederholen</span>";
localizedStrings["instructions"] = "Geben Sie die Stunden, Minuten und Sekunden in die Felder ein, oder wählen Sie einen Wert aus den unteren Listen.";
localizedStrings["sndPopup"] = "Wählen Sie einen Alarmton aus der Liste.";
localizedStrings["noSound"] = "Kein Ton";
localizedStrings["3-2-1 Bell"] = "3-2-1 Glocke";
localizedStrings["Done"] = "Fertig";
localizedStrings["helpButtonTitleTag"] = "3-2-1 Hilfe";

localizedStrings["laptimeLabelCutOffPoint"] = 323;
localizedStrings["buttonLabelsCutOffPoint"] = 190;