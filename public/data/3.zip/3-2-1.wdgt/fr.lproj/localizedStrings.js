var localizedStrings = new Array;

localizedStrings["StartUpTxt"] = "Cliquez ici pour entrer le temps.";

localizedStrings["clockClickToReset"] = "Cliquez pour réactiver.";
localizedStrings["null"] = "";
localizedStrings["custommsgtitle"] = "Message d'alerte:";
localizedStrings["timesupmessage"] = "Terminé!";

localizedStrings["Laptime"] = "TEMPS DE TOUR";
localizedStrings["Start"] = "Départ";
localizedStrings["Stop"] = "Arrêt";
localizedStrings["Lap on"] = "Compte tour";
localizedStrings["Lap off"] = "Arrêt tour";
localizedStrings["Reset"] = "Réactiver";

localizedStrings["textfieldstitle"] = "Compte à rebours:";
localizedStrings["notificationstitle"] = "Choix d'alarme:";
localizedStrings["labeltitle"] = "Étiquette:";
localizedStrings["labelfieldinstructions"] = "Entrez votre étiquette.";
localizedStrings["customMsgTextFieldTitleTag"] = "Entrez votre propre message d'alerte.";
localizedStrings["bringtofront"] = "<span title='Fait apparaître Dashboard s&#39;il est caché.'>Amener à l'avant</span>";
localizedStrings["repeatcheckboxtext"] = "<span title='Fait sonner l&#39;alarme jusqu&#39;à arrêt.'>Répéter le son</span>";
localizedStrings["instructions"] = "Entrez heures, minutes et secondes dans les boîtes, ou utilisez les listes défilantes.";
localizedStrings["sndPopup"] = "Selectionnez un son dans la liste.";
localizedStrings["noSound"] = "Pas de son";
localizedStrings["3-2-1 Bell"] = "Cloche 3-2-1";
localizedStrings["Done"] = "Prêt";
localizedStrings["helpButtonTitleTag"] = "Aide 3-2-1";

localizedStrings["laptimeLabelCutOffPoint"] = 354;
localizedStrings["buttonLabelsCutOffPoint"] = 190;