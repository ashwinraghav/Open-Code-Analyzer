var localizedStrings = new Array;

localizedStrings["StartUpTxt"] = "Clique aqui para marcar o tempo.";

localizedStrings["clockClickToReset"] = "Clique para reiniciar";
localizedStrings["null"] = "";
localizedStrings["custommsgtitle"] = "Mensagem de alerta:";
localizedStrings["timesupmessage"] = "Acabou o tempo!";
    
localizedStrings["Laptime"] = "<span style = 'font-size: 14px;line-height:22px;'>ESCONDER CONTAGEM</span>";
localizedStrings["Start"] = "Iniciar";
localizedStrings["Stop"] = "Parar";
localizedStrings["Lap on"] = "Mostrar contagem";
localizedStrings["Lap off"] = "Não mostrar contagem";
localizedStrings["Reset"] = "Reiniciar";

localizedStrings["textfieldstitle"] = "Iniciar contador em:";
localizedStrings["notificationstitle"] = "Notificações:";
localizedStrings["labeltitle"] = "Título:";
localizedStrings["labelfieldinstructions"] = "Título para o contador.";
localizedStrings["customMsgTextFieldTitleTag"] = "Entre sua própria mensagem de alerta.";
localizedStrings["bringtofront"] = "<span title='Quando o Dashboard estiver escondido torne-o ativo.'>Trazer para a frente</span>";
localizedStrings["repeatcheckboxtext"] = "<span title='Repetir o alarme até ser interrompido.'>Repetir o som</span>";
localizedStrings["instructions"] = "Digite a hora, minutos e segundos nos campos ou use as listas abaixo.";
localizedStrings["sndPopup"] = "Selecione um som da lista.";
localizedStrings["noSound"] = "Sem som";
localizedStrings["3-2-1 Bell"] = "Alarme 3-2-1";
localizedStrings["Done"] = "Pronto";
localizedStrings["helpButtonTitleTag"] = "Ajuda 3-2-1";

localizedStrings["laptimeLabelCutOffPoint"] = 420;
localizedStrings["buttonLabelsCutOffPoint"] = 222;