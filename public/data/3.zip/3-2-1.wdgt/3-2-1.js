//	3-2-1 Widget v2.1.1
//	Author:	BaldGeeks.com
//  02/07/08 

var debugAlertsEnabled = false;

//	Flags
var stopTime = 0;
var timeAtStart = 0;
var startStopToggle = 0;
var lapFlag = 0;
var resetFlag = 0;
var countingDown = 0;
var canShowButtonLabels = 1;
var customMsgFlag = 0;
var dashboardShown;
var soundOn;
var editingFlag;

//  Objects
var pauseHours, pauseMinutes, pauseSeconds;
var tickTimer;
var appleInfoButton, appleDoneButton;
var labelString;
var customTimesUpMessageString;
var windowWidth;
var usersFrontHeight, usersFrontWidth;
var growboxInset;
var clockFaderVSlow, clockFaderFast;
var labelCutOffPoint;

//  Sound
var trimRegExp = /^[ \t]+|[ \t]+$/;
var trimMoreRegExp = /^[ \t\n\r]+|[ \t\n\r]+$/;
var soundArray = new Array;
var pathArray = new Array;
var pathToSound = "";
var pathToSilence = "";

function debugAlerts(msg) {	 
    if (debugAlertsEnabled) {	 
        alert(msg);	 
    }	 
}

function initialSetUp() {

    debugAlerts("v2 Loading");	
   
    dashboardShown = true;
        
    appleInfoButton = new AppleInfoButton(document.getElementById("infoButton"), document.getElementById("front"), "white", "white", gotoPrefs);
	appleDoneButton = new AppleGlassButton(document.getElementById("doneButton"), getLocalizedString('Done'), finishedWithPrefs);

    document.getElementById('Laptime').innerHTML = getLocalizedString('Laptime');
	document.getElementById('startLabel').innerText = getLocalizedString('Start');
    document.getElementById('stopLabel').innerText = getLocalizedString('Stop');
	document.getElementById('laponLabel').innerHTML = getLocalizedString('Lap on');
    document.getElementById('lapoffLabel').innerHTML = getLocalizedString('Lap off');
    document.getElementById('resetLabel').innerHTML = getLocalizedString('Reset');
    
    document.getElementById('textfieldstitle').innerHTML = getLocalizedString('textfieldstitle');
    document.getElementById('customMsgTitle').innerHTML = getLocalizedString('custommsgtitle');
    document.getElementById('customMsgTextField').value = getLocalizedString('timesupmessage');
    document.getElementById('notificationstitle').innerHTML = getLocalizedString('notificationstitle');
    document.getElementById('labeltitle').innerHTML = getLocalizedString('labeltitle');
    document.getElementById('bringtofront').innerHTML = getLocalizedString('bringtofront');
    document.getElementById('repeatcheckboxtext').innerHTML = getLocalizedString('repeatcheckboxtext');
    document.getElementById('instructions').setAttribute("title", getLocalizedString('instructions') );
    document.getElementById('sndPopup').setAttribute("title", getLocalizedString('sndPopup') );
    document.getElementById('label').setAttribute("title", getLocalizedString('labelfieldinstructions') );
    document.getElementById('customMsgTextField').setAttribute("title", getLocalizedString('customMsgTextFieldTitleTag') );
    document.getElementById('helpButton').setAttribute("title", getLocalizedString('helpButtonTitleTag') );
    
    buttonLabelsCutOffPoint = getLocalizedString('buttonLabelsCutOffPoint');
    laptimeLabelCutOffPoint = getLocalizedString('laptimeLabelCutOffPoint'); // laptime switches off first
    debugAlerts('laptimeLabelCutOffPoint =' + laptimeLabelCutOffPoint);
    debugAlerts('buttonLabelsCutOffPoint =' + buttonLabelsCutOffPoint);
    
    // set up Clock div faders
    var element;
	element = document.getElementById("Clock");
	clockFaderVSlow = new Fader(element, null, 500, 0.0, 1.0);//(element, callback, fadeTime, minOpacity, maxOpacity)
	clockFaderFast  = new Fader(element, null, 300, 0.0, 1.0);
    
    populateSoundsPopup(); // get system sounds into array
    renderPrefsValues();
    resizeFrontToUsersDefaultSize();
    setSilenceSoundPath();    
    updateCheck();   
}

//- mark ## CONTROLS (front)
function StartStopToggle() {
    if (lapFlag == 0 && (document.getElementById('StartStopButton').className == 'startstoptoggleButtonStart'
        || document.getElementById('StartStopButton').className == 'startstoptoggleButtonStop') ) {
    
        if (countingDown == 0 && (startStopToggle == 0 || startStopToggle == 2)) {
            if (startStopToggle == 0) { // 1st press
                document.getElementById('update').style.display = 'none';
                startStopToggle = 1;
                document.getElementById('ResetButton').className = 'resetButtonOn';
                
                writePrefs();
            }
            else  { // release pause
                countingDown = 1;
            }
            
            document.getElementById('StartStopButton').className = 'startstoptoggleButtonStop';
            document.getElementById('LapButton').className = 'lapButtonOn';

            countDown();
        }
        else if (countingDown == 1 && startStopToggle == 1) { // pause On
            startStopToggle = 2;
            countingDown = 0;
            document.getElementById('StartStopButton').className = 'startstoptoggleButtonStart';
            document.getElementById('LapButton').className = 'lapButton';
        }
        editingFlag = "";
        document.getElementById('dummyClock').style.display = 'none';
    }
}

function Reset() {
    if (document.getElementById('ResetButton').className == 'resetButtonOn'  && lapFlag == 0) {  
    debugAlerts('Reset triggered'); 
        countingDown = 0;
        customMsgFlag = 0; // turn off customMsgFlag
        document.getElementById("soundEmbed").innerHTML = "";
        renderPrefsValues();
        // clear the 'clockClickToReset' title tag
        document.getElementById('Clock').setAttribute("title", getLocalizedString('null') );
        document.getElementById('dummyClock').style.display = 'none';
        document.getElementById('Clock').style.display = 'none';
        editingFlag = "";
        scaleFontSize();
    }
} 

function Lap() {
    if ( document.getElementById('LapButton').className == 'lapButtonOn' && countingDown == 1 ) {
    
		if (lapFlag == 0) { // first press
            lapFlag = 1;
            
            document.getElementById('Laptime').style.display = 'block';
            document.getElementById('Laptime').style.color = '#FF6600';

            if (windowWidth < 265) {
                document.getElementById('Laptime').style.display = 'none';
            }

            document.getElementById('StartStopButton').className = 'startstoptoggleButtonStopOff';	
            document.getElementById('ResetButton').className = 'resetButton';	
            document.getElementById("Clock").style.color = "#FF6600";
		}
		else  { // resume from lap
            lapFlag = 0;
            document.getElementById('Laptime').style.display = 'none';
            document.getElementById('StartStopButton').className = 'startstoptoggleButtonStop';	
            document.getElementById('ResetButton').className = 'resetButtonOn';
            document.getElementById("Clock").style.color = "#FFFFFF";
            formatString();
		}
    }
}

function editClockTimeHours(event) {
    if ( (event.keyCode == 0 || event.keyCode == 9) && countingDown != 1 && editingFlag != "hours") { // if mouse click, & we're not counting or editing
        debugAlerts('editing hours ');
        editingFlag = "hours";
        document.getElementById("dummyClock").innerHTML = "<img src='images/flipflop1.png' width='100%' style='opacity:0.5;'/>"; 
        document.getElementById('dummyClock').style.display = 'block';
        document.getElementById('dummyClock').style.opacity = '1.0';
    }
    else if (editingFlag == "hours") { // second click
        debugAlerts('editing OFF ');
        editingFlag = "";
        document.getElementById('dummyClock').style.display = 'none';       
    }
}

function editClockTimeMinutes(event) {
    if ( (event.keyCode == 0 || event.keyCode == 9) && countingDown != 1 && editingFlag != "minutes") {
        debugAlerts('editing minutes ');
        editingFlag = "minutes";
        document.getElementById("dummyClock").innerHTML = "<img src='images/flipflop2.png' width='100%' style='opacity:0.5;'/>"; 
        document.getElementById('dummyClock').style.display = 'block';
        document.getElementById('dummyClock').style.opacity = '1.0';
    }
    else if (editingFlag == "minutes") { // second click
        debugAlerts('editing OFF ');
        editingFlag = "";
        document.getElementById('dummyClock').style.display = 'none';
    }
}

function editClockTimeSeconds(event) {
    if ( (event.keyCode == 0 || event.keyCode == 9) && countingDown != 1 && editingFlag != "seconds") {
        debugAlerts('editing seconds ');
        editingFlag = "seconds";
        document.getElementById("dummyClock").innerHTML = "<img src='images/flipflop3.png' width='100%' style='opacity:0.5;'/>"; 
        document.getElementById('dummyClock').style.display = 'block';
        document.getElementById('dummyClock').style.opacity = '1.0';
    }
    else if (editingFlag == "seconds") { // second click
        debugAlerts('editing OFF ');
        editingFlag = "";
        document.getElementById('dummyClock').style.display = 'none';
    }
}

function keyDown(event) {
    // Front - process keypresses/scroll
    if (document.getElementById("front").style.display != "none") {
        
        //debugAlerts('front key pressed ' + event.keyCode);
        
        if(event.keyCode == 32) { // spacebar
            event.preventDefault();
            //debugAlerts('enter ');
            StartStopToggle();
        }
        
        else if (event.keyCode == 9  && editingFlag != "") { // tab key pressed and we're editing
            if ( editingFlag == "hours" ) {
                editingFlag = "";
                editClockTimeMinutes(event);
            }
            else if ( editingFlag == "minutes" ) {
                editingFlag = "";
                editClockTimeSeconds(event);
            }
            else if ( editingFlag == "seconds" ) {
                editingFlag = "";
                document.getElementById('dummyClock').style.display = 'none'; 
            }
        }
        
        else if (event.keyCode == 9  && editingFlag == "") { // tab key pressed and we're not yet editing
            editClockTimeHours(event);
        }
                
        else if ( editingFlag == "hours" && countingDown != 1) {
        
            if ( event.keyCode == 43 || event.keyCode == 61 || event.wheelDelta >= 12 ) { // + 
  /*          
                // slows it down too much, plus what about accelerated mice 
                debugAlerts('event.wheelDelta= '+event.wheelDelta);
                var wheelFactor;
                
                if (event.wheelDelta < 121) {
                    wheelFactor = 1;
                }
                else if (event.wheelDelta < 200) {
                    wheelFactor = 2;
                }
                else if (event.wheelDelta < 350) {
                    wheelFactor = 3;
                }
                else if (event.wheelDelta < 600) {
                    wheelFactor = 4;
                }
                else if (event.wheelDelta < 2000) {
                    wheelFactor = 5;
                }
                else {
                    wheelFactor = 10;
                }
            
  */          
                event.preventDefault();
                if (currentHoursRound == 00) {
                    currentHoursRound = "01";
                }
                else {
                    var tmp = (+currentHoursRound) + 1;
                    currentHoursRound = tmp + '';
                                        
                    if (currentHoursRound.length == 1) { 
                        currentHoursRound = "0"+currentHoursRound;
                    }
                    if (currentHoursRound > 99) {
                    currentHoursRound = "00";
                    }
                }
                document.getElementById('countDownFromHours').value = currentHoursRound;
                //writePrefs();
                renderString();
            }
            
            else if ( event.keyCode == 45 || event.wheelDelta <= -12 ) { // - 
                event.preventDefault();
                if (currentHoursRound == 00) {
                    currentHoursRound = "99";
                }
                else {
                    var tmp = (+currentHoursRound) - 1;
                    currentHoursRound = tmp + '';
                    if (currentHoursRound.length == 1) { 
                        currentHoursRound = "0"+currentHoursRound;
                    }
                }
                document.getElementById('countDownFromHours').value = currentHoursRound;
                //writePrefs();
                renderString();
            }
            // number keys
            else if ( event.keyCode >= 48 && event.keyCode <= 57 ) {
                event.preventDefault();
                                
                var numberKeyFirstPressValue = ''+currentHoursRound;
                numberKeyFirstPressValue = numberKeyFirstPressValue.charAt(1);
                
                if (event.keyCode == 48) { // 0
                        currentHoursRound = numberKeyFirstPressValue+"0";
                }
                else if (event.keyCode == 49) { // 1
                        currentHoursRound = numberKeyFirstPressValue+"1";
                }
                else if (event.keyCode == 50) { // 2
                        currentHoursRound = numberKeyFirstPressValue+"2";
                }
                else if (event.keyCode == 51) { // 3
                        currentHoursRound = numberKeyFirstPressValue+"3";
                }
                else if (event.keyCode == 52) { // 4
                        currentHoursRound = numberKeyFirstPressValue+"4";
                }
                else if (event.keyCode == 53) { // 5
                        currentHoursRound = numberKeyFirstPressValue+"5";
                }
                else if (event.keyCode == 54) { // 6
                        currentHoursRound = numberKeyFirstPressValue+"6";
                }
                else if (event.keyCode == 55) { // 7
                        currentHoursRound = numberKeyFirstPressValue+"7";
                }
                else if (event.keyCode == 56) { // 8
                        currentHoursRound = numberKeyFirstPressValue+"8";
                }
                else if (event.keyCode == 57) { // 9
                        currentHoursRound = numberKeyFirstPressValue+"9";
                }
                
                document.getElementById('countDownFromHours').value = currentHoursRound;
                //writePrefs();
                renderString();
            }
           
            // if we're on pause - update pauseTime  
            if (startStopToggle == 2) {
              pauseHours = currentHoursRound;
            }
        }
        else if ( editingFlag == "minutes" && countingDown != 1) {
        
            if (event.keyCode == 43 || event.keyCode == 61 || event.wheelDelta >= 12 ) { // + 
                event.preventDefault();
                if (currentMinutesRound == 00) {
                    currentMinutesRound = "01";
                }
                else {
                    var tmp = (+currentMinutesRound) + 1;
                    currentMinutesRound = tmp + '';
                    if (currentMinutesRound.length == 1) { 
                        currentMinutesRound = "0"+currentMinutesRound;
                    }
                    if (currentMinutesRound > 59) {
                    currentMinutesRound = "00";
                    }
                }
                document.getElementById('countDownFromMinutes').value = currentMinutesRound;
                //writePrefs();
                renderString();
            }
            
            else if (event.keyCode == 45 || event.wheelDelta <= -12 ) { // - 
                event.preventDefault();
                if (currentMinutesRound == 00) {
                    currentMinutesRound = "59";
                }
                else {
                    var tmp = (+currentMinutesRound) - 1;
                    currentMinutesRound = tmp + '';

                    if (currentMinutesRound.length == 1) { 
                        currentMinutesRound = "0"+currentMinutesRound;
                    }
                }
                document.getElementById('countDownFromMinutes').value = currentMinutesRound;
                //writePrefs();
                renderString();
            }
            // number keys
            else if ( event.keyCode >= 48 && event.keyCode <= 57 ) {
                event.preventDefault();
                
                var numberKeyFirstPressValue = ''+currentMinutesRound;
                numberKeyFirstPressValue = numberKeyFirstPressValue.charAt(1);
                
                if (event.keyCode == 48) { // 0
                        currentMinutesRound = numberKeyFirstPressValue+"0";
                }
                else if (event.keyCode == 49) { // 1
                        currentMinutesRound = numberKeyFirstPressValue+"1";
                }
                else if (event.keyCode == 50) { // 2
                        currentMinutesRound = numberKeyFirstPressValue+"2";
                }
                else if (event.keyCode == 51) { // 3
                        currentMinutesRound = numberKeyFirstPressValue+"3";
                }
                else if (event.keyCode == 52) { // 4
                        currentMinutesRound = numberKeyFirstPressValue+"4";
                }
                else if (event.keyCode == 53) { // 5
                        currentMinutesRound = numberKeyFirstPressValue+"5";
                }
                else if (event.keyCode == 54) { // 6
                        currentMinutesRound = numberKeyFirstPressValue+"6";
                }
                else if (event.keyCode == 55) { // 7
                        currentMinutesRound = numberKeyFirstPressValue+"7";
                }
                else if (event.keyCode == 56) { // 8
                        currentMinutesRound = numberKeyFirstPressValue+"8";
                }
                else if (event.keyCode == 57) { // 9
                        currentMinutesRound = numberKeyFirstPressValue+"9";
                }
                
                document.getElementById('countDownFromMinutes').value = currentMinutesRound;
                //writePrefs();
                renderString();
            }
            
            if (startStopToggle == 2) {
            pauseMinutes = currentMinutesRound;
            } 
        } // end minutes edit mode
        
        else if ( editingFlag == "seconds" && countingDown != 1) {
        
            if (event.keyCode == 43 || event.keyCode == 61 || event.wheelDelta >= 12 ) { // + 
                event.preventDefault();
                if (currentSecondsRound == 00) {
                    currentSecondsRound = "01";
                }
                else {
                    var tmp = (+currentSecondsRound) + 1;
                    currentSecondsRound = tmp + '';
                    if (currentSecondsRound.length == 1) { 
                        currentSecondsRound = "0"+currentSecondsRound;
                    }
                    if (currentSecondsRound > 59) {
                    currentSecondsRound = "00";
                    }
                }
                document.getElementById('countDownFromSeconds').value = currentSecondsRound;
                //writePrefs();
                renderString();
            }
            
            else if (event.keyCode == 45 || event.wheelDelta <= -12 ) { // -
                event.preventDefault(); 
                if (currentSecondsRound == 00) {
                    currentSecondsRound = "59";
                }
                else {
                    var tmp = (+currentSecondsRound) - 1;
                    currentSecondsRound = tmp + '';

                    if (currentSecondsRound.length == 1) { 
                        currentSecondsRound = "0"+currentSecondsRound;
                    }
                }
                document.getElementById('countDownFromSeconds').value = currentSecondsRound;
                //writePrefs();
                renderString();
            }
            
            // number keys
            else if ( event.keyCode >= 48 && event.keyCode <= 57 ) {
                event.preventDefault();

                var numberKeyFirstPressValue = ''+currentSecondsRound;
                numberKeyFirstPressValue = numberKeyFirstPressValue.charAt(1);
                
                if (event.keyCode == 48) { // 0
                        currentSecondsRound = numberKeyFirstPressValue+"0";
                }
                else if (event.keyCode == 49) { // 1
                        currentSecondsRound = numberKeyFirstPressValue+"1";
                }
                else if (event.keyCode == 50) { // 2
                        currentSecondsRound = numberKeyFirstPressValue+"2";
                }
                else if (event.keyCode == 51) { // 3
                        currentSecondsRound = numberKeyFirstPressValue+"3";
                }
                else if (event.keyCode == 52) { // 4
                        currentSecondsRound = numberKeyFirstPressValue+"4";
                }
                else if (event.keyCode == 53) { // 5
                        currentSecondsRound = numberKeyFirstPressValue+"5";
                }
                else if (event.keyCode == 54) { // 6
                        currentSecondsRound = numberKeyFirstPressValue+"6";
                }
                else if (event.keyCode == 55) { // 7
                        currentSecondsRound = numberKeyFirstPressValue+"7";
                }
                else if (event.keyCode == 56) { // 8
                        currentSecondsRound = numberKeyFirstPressValue+"8";
                }
                else if (event.keyCode == 57) { // 9
                        currentSecondsRound = numberKeyFirstPressValue+"9";
                }

                document.getElementById('countDownFromSeconds').value = currentSecondsRound;
                //writePrefs();
                renderString();
            } // end number keys
            
            if (startStopToggle == 2) {
            pauseSeconds = currentSecondsRound;
            }
        }
    } // end front
    
    // Back - process keypresses
    else { 
        debugAlerts('back key pressed ' + event.keyCode);
    
        if(event.keyCode == 13 || event.keyCode == 3) { // enter & return keys
            event.preventDefault();
                if (document.getElementById("back").offsetHeight == 290) {
                    finishedWithPrefs();
                }
            }
        //else if(event.keyCode == 9) { // tab
            //event.preventDefault();
            
        //    }
    } // end back
}

function showstartstopLabel() { 
    if (canShowButtonLabels == 1 && lapFlag == 0) { // for startstopbutton
        if (countingDown == 0 && startStopToggle != 1) {
            document.getElementById('stopLabel').style.display = 'none';
            document.getElementById('startLabel').style.display = 'block';
            document.getElementById('startLabel').style.opacity = '1.0';
            // if times up or button already disabled - eg. 1st time launched
            if (startStopToggle == 3 || document.getElementById('StartStopButton').className == 'startstoptoggleButtonStartOff') { 
                // show label disabled
                document.getElementById('startLabel').style.opacity = '0.2';
            }
        }
        else {
            document.getElementById('startLabel').style.display = 'none';
            document.getElementById('stopLabel').style.display = 'block';
        }
    }
}

function showlapLabel() {
    if (canShowButtonLabels == 1) {
        if (lapFlag == 1) { // show lapOff label
            document.getElementById('laponLabel').style.display = 'none';
            document.getElementById('lapoffLabel').style.display = 'block';
        }
        else if (lapFlag == 0 && startStopToggle != 1) { // show lapOn disabled
            document.getElementById('lapoffLabel').style.display = 'none';
            document.getElementById('laponLabel').style.display = 'block';
             if ( countingDown == 0 ) {
                document.getElementById('laponLabel').style.opacity = '0.2';     
             }
             else {
                document.getElementById('laponLabel').style.opacity = '1.0';
             }
        }
        else if (lapFlag == 0 && startStopToggle == 1) {
            document.getElementById('laponLabel').style.display = 'block';
            document.getElementById('laponLabel').style.opacity = '1.0';
        }
    }
}

function showresetLabel() {
     if (lapFlag == 0  && canShowButtonLabels == 1) {
     document.getElementById('resetLabel').style.display = 'block';
     
         if ( countingDown == 0 ) {
             if (startStopToggle == 0) {
                 document.getElementById('resetLabel').style.opacity = '0.2';
             }
             if (startStopToggle == 2 || startStopToggle == 3) {
                 document.getElementById('resetLabel').style.opacity = '1.0';
             }
         }
         else {
             if (startStopToggle == 1) {
                 document.getElementById('resetLabel').style.opacity = '1.0';
             }
         }
    }
}

function hideLabels() {
    document.getElementById('startLabel').style.display = 'none';
    document.getElementById('stopLabel').style.display = 'none';
    document.getElementById('lapoffLabel').style.display = 'none';
    document.getElementById('laponLabel').style.display = 'none';
    document.getElementById('resetLabel').style.display = 'none';
}

//- mark ## CONTROLS (back)
function toggleRepeat() {
    var repeatSnd = document.getElementById('repeatcheckbox').checked;
    widget.setPreferenceForKey(repeatSnd,prefsKey("repeatSnd"));
}

function toggleNotifyme() {
    var notifyMe = document.getElementById('notifymecheckbox').checked;
    widget.setPreferenceForKey(notifyMe,prefsKey("notifyMe"));
}

function showSndRepeatDiv() {
    document.getElementById('repeatcheckboxtext').style.opacity = '1.0';
    document.getElementById('repeatcheckbox').style.opacity = '1.0';
}

function hideSndRepeatDiv() {
    document.getElementById('repeatcheckboxtext').style.opacity = '0.15';
    document.getElementById('repeatcheckbox').style.opacity = '0.15';
}

function paypalover() {
    document.getElementById('paypalbutton').style.background = "url(images/donate_button_o.png) no-repeat top left";
}

function paypaloff() {
    document.getElementById('paypalbutton').style.background = "url(images/donate_button.png) no-repeat top left";
}

function updateover() {
    document.getElementById('lrgUpdateP2').src = "images/update/lrgUpdateP2over.png";
}

function updateoff() {
    document.getElementById('lrgUpdateP2').src = "images/update/lrgUpdateP2.png";
}

function updatesmlover() {
    document.getElementById('smlUpdateP2').src = "images/update/smlUpdateP2over.png";
}

function updatesmloff() {
    document.getElementById('smlUpdateP2').src = "images/update/smlUpdateP2.png";
}

//- mark ## COUNTDOWN
function countDown() {
		startTime = new Date();
		timeAtStart = startTime.getTime();

	if ( startStopToggle == 1) { // Start cd
		countdownSeconds = document.getElementById('countDownFromSeconds').value;
		countdownMinutes = document.getElementById('countDownFromMinutes').value;
        countdownHours = document.getElementById('countDownFromHours').value;
		countDownFromValue = (countdownHours * 3600000) + (countdownMinutes * 60000) + (countdownSeconds * 1000);
		stopTime = (timeAtStart + countDownFromValue);
		countingDown = 1;
    }
	else  { // Resume cd
		countDownFromValue = (pauseHours * 3600000) + (pauseMinutes * 60000) + (pauseSeconds * 1000);
		stopTime = (timeAtStart + countDownFromValue);
		startStopToggle = 1;
    }

    tickTimer = window.setInterval("tick();", 1000);
}

function tick() { // if counting down, tick and display result

    if (startStopToggle == 1 && countingDown == 1 && resetFlag == 0) {
        timeNow = new Date();
        currentTime = timeNow.getTime();
        currentHours = (stopTime - currentTime) / 3600000;
        currentHoursRound = Math.floor(currentHours);
        currentMinutes = (stopTime - currentTime) / 60000 - (60 * currentHoursRound);
        currentMinutesRound = Math.floor(currentMinutes);
        currentSeconds = (stopTime - currentTime) / 1000 - (3600 * currentHoursRound) - (60 * currentMinutesRound) ;
        currentSecondsRound = Math.round(currentSeconds);
        
        if (lapFlag == 0) {
            formatString();
        }
    }

    if (currentHoursRound == 0 && currentMinutesRound == 0 && currentSecondsRound == 0) {    // check for times up!

        alertSound(repeatSnd);
        bringDashboardToFront();
        startStopToggle = 3;
        countingDown = 0;
        lapFlag = 0;

        document.getElementById('Laptime').style.display = 'none';
        document.getElementById('LapButton').className = 'lapButton';
        document.getElementById('StartStopButton').className = 'startstoptoggleButtonStartOff';
        document.getElementById('ResetButton').className = 'resetButtonOn';
        
        clearInterval(tickTimer);
    }
    else if (currentTime >= stopTime) {    // check for times up while sleeping
        alertSound(repeatSnd);
        bringDashboardToFront();
        startStopToggle = 3;
        countingDown = 0;
        lapFlag = 0;
        document.getElementById('Laptime').style.display = 'none';
        document.getElementById('LapButton').className = 'lapButton';
        document.getElementById('StartStopButton').className = 'startstoptoggleButtonStartOff';
        document.getElementById('ResetButton').className = 'resetButtonOn';

        clearInterval(tickTimer);
    }
    else if (startStopToggle == 2 && countingDown == 0 && lapFlag == 0) {    // if PAUSED remember starting value
        pauseSeconds = currentSecondsRound;
        pauseMinutes = currentMinutesRound;
        pauseHours = currentHoursRound;

        clearInterval(tickTimer);
    }
    else if ( resetFlag == 1 || startStopToggle == 0 ) {    // check for RESET being pressed during tick loop (countdown)
        countingDown = 0;
        clearInterval(tickTimer);
    }
}

//- mark ## RENDER OUTPUT
function formatString() {

//debugAlerts('formatString');

    // check for "60" secs & mins while counting
    if (currentSecondsRound == 60) { 
        currentSecondsRound = 0;
        if (currentMinutesRound >= 1) {
            currentMinutesRound = currentMinutesRound + 1;
        }
        else {
            currentMinutesRound = 1;
        }
    }
    
    if (currentMinutesRound >= 60) {
        currentMinutesRound = currentMinutesRound - 60;
        if (currentHoursRound >= 1 && currentHoursRound < 99) {
            currentHoursRound = currentHoursRound + 1;
        }
        else if (currentHoursRound >= 99) {
            currentHoursRound = 99;
        }
        else {
            currentHoursRound = 1;
        }
    }

    // pad xtra 0's 
    if (currentHoursRound < 10) { 
        currentHoursRound = "0"+currentHoursRound; 
		}
    if (currentMinutesRound < 10) { 
        currentMinutesRound = "0"+currentMinutesRound;
		}
    if (currentSecondsRound < 10) { 
        currentSecondsRound = "0"+currentSecondsRound;
    }

    renderString();
}

function renderString() {
    if ( lapFlag == 1 ) { 
            document.getElementById('Clock').setAttribute("style", "color:#FF6600; text-shadow:#000 4px 4px 4px");
    }

    else {  // RENDER
        // HOURS
		if (currentHoursRound != "00") {
            renderHours = "<span onmousedown='editClockTimeHours(event);' onmousewheel='keyDown(event);'>"+currentHoursRound+":</span>";
            }
        else {
            renderHours = "<span style = 'opacity: 0.15;' onmousedown='editClockTimeHours(event);' onmousewheel='keyDown(event);'>00:</span>";
            }
		// MINUTES
		if (currentMinutesRound != "00") { 
            renderMinutes = "<span onmousedown='editClockTimeMinutes(event);' onmousewheel='keyDown(event);'>"+currentMinutesRound+":</span>";
            }
        else {
                if (renderHours != "<span style = 'opacity: 0.15;' onmousedown='editClockTimeHours(event);' onmousewheel='keyDown(event);'>00:</span>") {
                renderMinutes = "<span onmousedown='editClockTimeMinutes(event);' onmousewheel='keyDown(event);'>"+currentMinutesRound+":</span>";
                }
                else {
                renderMinutes = "<span style = 'opacity: 0.15;' onmousedown='editClockTimeMinutes(event);' onmousewheel='keyDown(event);'>00:</span>";
                }
            }
		// SECONDS
        if (currentSecondsRound != "00") { 
            renderSeconds = "<span onmousedown='editClockTimeSeconds(event);' onmousewheel='keyDown(event);'>"+currentSecondsRound+"</span>";
        }
        else {
                if (renderMinutes != "<span style = 'opacity: 0.15;' onmousedown='editClockTimeMinutes(event);' onmousewheel='keyDown(event);'>00:</span>") {
                    renderSeconds = "<span onmousedown='editClockTimeSeconds(event);' onmousewheel='keyDown(event);'>"+currentSecondsRound+"</span>";
                }
                else {
                    renderSeconds = "<span style = 'opacity: 0.15;' onmousedown='editClockTimeSeconds(event);' onmousewheel='keyDown(event);'>00</span>";
                }
            }  
        Clock.innerHTML =  renderHours +renderMinutes +renderSeconds;
    }
}

function renderPrefsValues() {
    
    if (countingDown == 0) { // if we're not counting - reset back to prefs values
debugAlerts('renderPrefsValues');
        startStopToggle = 0;
        resetFlag = 0;
        lapFlag = 0;
        
        // set clock to wht
        document.getElementById('Clock').style.opacity = '0.0';
        document.getElementById('Clock').style.display = 'block'; 
        document.getElementById("Clock").style.color = "#FFFFFF";
            
        hideLabels();    
        document.getElementById('Laptime').style.display = 'none';
        document.getElementById('startLabel').style.opacity = '1.0';
        document.getElementById('stopLabel').style.opacity = '1.0';
        document.getElementById('lapoffLabel').style.opacity = '1.0';
        document.getElementById('laponLabel').style.opacity = '1.0';
        document.getElementById('resetLabel').style.opacity = '1.0';
        document.getElementById('LapButton').className = 'lapButton';
        document.getElementById('ResetButton').className = 'resetButton';
        document.getElementById('StartStopButton').className = 'startstoptoggleButtonStart';
    }
    readPrefs();
}

function scaleFontSize() {
var fSize, shadowOffset;

    // if showing update div - reload it - in case size has changed
    if (document.getElementById('update').style.display == 'block') {
        compareVersion();
    }

    if ( customMsgFlag == 1 || customMsgFlag == 2 ) { // scaleMessageSize 1 or 2 - strtup txt or times-up msg
        debugAlerts('ignoring scaleFontSize ' +customMsgFlag);
        scaleMessageSize(customMsgFlag);
    }
    
    else {
        debugAlerts('scaleFontSize');

        document.getElementById('Clock').style.display = 'block';
        frontElement = document.getElementById("Clock");
        
        frontElementStyle = document.defaultView.getComputedStyle(frontElement, "");
        windowWidth = parseInt(frontElementStyle.getPropertyValue("width"));
        var lineL = document.getElementById("Clock").innerText.length;
        
        debugAlerts('windowWidth =' +windowWidth);
    
        fSize = (60 * (windowWidth / 290) );
            
        fSize = (fSize * ( 8 / lineL ) ); // scale string according to its length
        
        shadowOffset = (4 * (fSize / 60) ); // scale shadow offset relative to font size
    
    
        var padding = ( (12/400) * fSize) + 12;
        
        if (fSize < 28) { // mini size defaults
            fSize = fSize * 0.95;
            padding = 14.0;
        }
               
        // limit shadow size
        if (shadowOffset > 20) { 
            shadowOffset = 20;
        }
        else if (shadowOffset < 2) {
                 shadowOffset = 2;
        }
        
        // style up Clock
        document.getElementById('Clock').setAttribute("style", "opacity:0.0; font-size:" +fSize+"px; padding-top:" + padding + "px; " + "text-shadow:#000 " +shadowOffset+"px "+shadowOffset+"px "+shadowOffset+"px;");
    
        // handle labels, tooltips and laptime field
        if (windowWidth < buttonLabelsCutOffPoint) {
            canShowButtonLabels = 0;
            // show labels as tooltips instead
            document.getElementById('StartStopButton').setAttribute("title", getLocalizedString('Start') +"/"+ getLocalizedString('Stop'));
            document.getElementById('LapButton').setAttribute("title", getLocalizedString('Lap on') +"/"+ getLocalizedString('Lap off'));
            document.getElementById('ResetButton').setAttribute("title", getLocalizedString('Reset') );
            
            if (lapFlag == 1) {
                document.getElementById('Laptime').style.display = 'none';
            }
        }
        else {
            canShowButtonLabels = 1;
            // cancel tooltip labels
            document.getElementById('StartStopButton').setAttribute("title", getLocalizedString('null') );
            document.getElementById('LapButton').setAttribute("title", getLocalizedString('null') );
            document.getElementById('ResetButton').setAttribute("title", getLocalizedString('null') );
        }
    
        if (lapFlag == 1) { // change colour and hide/show Lap Time txt
            document.getElementById("Clock").style.color = "#FF6600";
            if (windowWidth > laptimeLabelCutOffPoint) {
                document.getElementById('Laptime').style.display = 'block';
            }
        }
    clockFaderFast.fadeTo(0.0, 1.0);
    }
}

function scaleMessageSize(msgNumber) {
var fSize, shadowOffset; 

    // if showing update div - reload it - in case size has changed
    if (document.getElementById('update').style.display == 'block') {
        compareVersion();
    }

    if (msgNumber == "1") { // Startup message
        debugAlerts('scaleMessageSize ' + msgNumber);
        customMsgFlag = 1;
        document.getElementById('Clock').style.opacity = '0.0';
        document.getElementById('Clock').style.display = 'block'; 
        var tempMsg = getLocalizedString('StartUpTxt');
        // make ClockMsg span and handle onClick
        document.getElementById("Clock").innerHTML = "<span id='ClockMsg' onClick='gotoPrefs();'>" + tempMsg + "</span>";  
        usersFrontHeight = window.innerHeight - 20;
    }

    else { // Alert Message ('Time's Up!'), click to reset
        debugAlerts('scaleMessageSize ' + msgNumber);
        customMsgFlag = 2;
        document.getElementById('StartStopButton').className = 'startstoptoggleButtonStartOff';
        document.getElementById('ResetButton').className = 'resetButtonOn';
        document.getElementById('Clock').style.opacity = '0.0';
        document.getElementById('Clock').style.display = 'block';
        document.getElementById('Clock').setAttribute("title", getLocalizedString('clockClickToReset') );
        
        // restrict minimum msg size, to prevent too great a font size
        if (customTimesUpMessageString.length < 13) { 
            
            if (customTimesUpMessageString.length > 9) { //  
                customTimesUpMessageString = "&nbsp;" + customTimesUpMessageString + "&nbsp;";
            }
            else if (customTimesUpMessageString.length > 3) { // 4 - 8
                customTimesUpMessageString = "&nbsp; &nbsp;" + customTimesUpMessageString + "&nbsp; &nbsp;";
            }
            else { // 1 - 3
                customTimesUpMessageString = "&nbsp;&nbsp; &nbsp;" + customTimesUpMessageString + "&nbsp; &nbsp;&nbsp;";
            }
        }

        
        document.getElementById("Clock").innerHTML = "<span id='ClockMsg' onClick='Reset();'>" + customTimesUpMessageString + "</span>";
        usersFrontHeight = window.innerHeight - 40;
   }
   
    // scale font
    var lineL = document.getElementById("Clock").innerText.length;

	usersFrontWidth = window.innerWidth;
	
    // font size - based on window width and number of characters
    fSize = (60 * (usersFrontWidth / 290) );   
    fSize = (fSize * ( 8 / (lineL+1) ) ); // scale string according to its length
    
    // shadow
    shadowOffset = (4 * (fSize / 60) ); // scale shadow offset relative to font size
    // max/min shadow size
    if (shadowOffset > 20) { 
        shadowOffset = 20;
    }
    else if (shadowOffset < 2) {
             shadowOffset = 2;
    }
    
    document.getElementById('ClockMsg').setAttribute("style", "cursor: pointer; display: table-cell; vertical-align: middle; font-size:" +fSize+"px; " + "text-shadow:#000 " +shadowOffset+"px "+shadowOffset+"px "+shadowOffset+"px; width: "+usersFrontWidth+"px; height: "+usersFrontHeight+"px; color:#FFFFFF;");

    if (usersFrontWidth < buttonLabelsCutOffPoint) {
        canShowButtonLabels = 0;
        // show labels as tooltips instead
        document.getElementById('StartStopButton').setAttribute("title", getLocalizedString('Start') +"/"+ getLocalizedString('Stop'));
        document.getElementById('LapButton').setAttribute("title", getLocalizedString('Lap on') +"/"+ getLocalizedString('Lap off'));
        document.getElementById('ResetButton').setAttribute("title", getLocalizedString('Reset') );
        
        if (lapFlag == 1) {
            document.getElementById('Laptime').style.display = 'none';
        }
    }
    else {
        canShowButtonLabels = 1;
        // cancel tooltip labels
        document.getElementById('StartStopButton').setAttribute("title", getLocalizedString('null') );
        document.getElementById('LapButton').setAttribute("title", getLocalizedString('null') );
        document.getElementById('ResetButton').setAttribute("title", getLocalizedString('null') );
    }
    
    if (lapFlag == 1) { // change colour and hide/show Lap Time txt
        document.getElementById("Clock").style.color = "#FF6600";
        if (usersFrontWidth > laptimeLabelCutOffPoint) {
            document.getElementById('Laptime').style.display = 'block';
        }
    }
    if (customMsgFlag == 2) { 
        debugAlerts('show msg2 ' +customMsgFlag);
        document.getElementById('Clock').style.opacity = '1.0';
    }
    if (customMsgFlag == 1) {
        //clockFaderVSlow.fadeIn();
        debugAlerts('fade msg1');
        
        var element;
        element = document.getElementById("Clock");
        clockFaderMsg1 = new Fader(element, null, 500, 0.0, 1.0);//(element, callback, fadeTime, minOpacity, maxOpacity)
        clockFaderMsg1.fadeIn();
    }
    usersFrontHeight = window.innerHeight; // reset usersFrontHeight in case clock uses it next   
}

//- mark ## 3-2-1 PREFS
function prefsKey(key) {
	return widget.identifier + "-" + key;
}

function writePrefs() { 
var formattedHoursPref = document.getElementById('countDownFromHours').value;
var formattedMinutesPref = document.getElementById('countDownFromMinutes').value;
var formattedSecondsPref = document.getElementById('countDownFromSeconds').value;
var labelStringPref = document.getElementById('label').value;
customTimesUpMessageString = document.getElementById('customMsgTextField').value;

    // check we've got valid numbers
    if (!isInteger(formattedHoursPref)) {
        formattedHoursPref = "00";
    }
    if (!isInteger(formattedMinutesPref)) {
        formattedMinutesPref = "00";
    }
    if (!isInteger(formattedSecondsPref)) {
        formattedSecondsPref = "00";
    }

    // check for 60 or above
    if (formattedSecondsPref > 60 ) { // if seconds > 60
        var tmp = (+formattedSecondsPref) - 60;
        formattedSecondsPref = tmp + '';
        var tmp2 = (+formattedMinutesPref) + 1;
        formattedMinutesPref = tmp2 + '';
    }
    if (formattedSecondsPref == 60 ) { // if seconds = 60
        formattedSecondsPref = "00";
        var tmp = (+formattedMinutesPref) + 1;
        formattedMinutesPref = tmp + '';
    }
    if (formattedMinutesPref > 60 ) {
        var tmp = (+formattedMinutesPref) - 60;
        formattedMinutesPref = tmp + '';
        var tmp2 = (+formattedHoursPref) + 1;
        formattedHoursPref = tmp2 + '';
    }
    if (formattedMinutesPref == 60 ) {
        formattedMinutesPref = "00";
        var tmp = (+formattedHoursPref) + 1;
        formattedHoursPref = tmp + '';
    }
    if (formattedHoursPref > 99 ) {
        formattedHoursPref = "99";
    }
    // fill in blank fields with 00
    if (formattedHoursPref.length == 0)	{
        formattedHoursPref = "00";
    }
    if (formattedMinutesPref.length == 0) {
        formattedMinutesPref = "00";
    }
    if (formattedSecondsPref.length == 0) {
        formattedSecondsPref = "00";
    }
    // if we have a single digit value add a leading 0
    if (formattedSecondsPref.length == 1) { 
        formattedSecondsPref = "0"+formattedSecondsPref;
    }
    if (formattedMinutesPref.length == 1) { 
        formattedMinutesPref = "0"+formattedMinutesPref;
    }
    if (formattedHoursPref.length == 1) { 
        formattedHoursPref = "0"+formattedHoursPref;
    }
    // trim values > 2 to 00
    if (formattedHoursPref.length > 2) { 
        formattedHoursPref = "00";
    }
    if (formattedMinutesPref.length > 2) {
        formattedMinutesPref = "00";
    }
    if (formattedSecondsPref.length > 2) {
        formattedSecondsPref = "00";
    }

    // save new formatted time prefs
    widget.setPreferenceForKey(formattedHoursPref,prefsKey("lastSelectedHours"));
    widget.setPreferenceForKey(formattedMinutesPref,prefsKey("lastSelectedMinutes"));
    widget.setPreferenceForKey(formattedSecondsPref,prefsKey("lastSelectedSeconds"));
    document.getElementById('countDownFromHours').value = formattedHoursPref;
    document.getElementById('countDownFromMinutes').value = formattedMinutesPref;
    document.getElementById('countDownFromSeconds').value = formattedSecondsPref;
    widget.setPreferenceForKey(labelStringPref,prefsKey("labelString"));
    widget.setPreferenceForKey(customTimesUpMessageString,prefsKey("customTimesUpMessageString"));
    
    debugAlerts('Hours' +formattedHoursPref);
    debugAlerts('Mins ' +formattedMinutesPref);
    debugAlerts('Secs ' +formattedSecondsPref);
}

function readPrefs() {
    if ( countingDown == 1  || startStopToggle == 2 || startStopToggle == 3) {
    // if counting down - read notification prefs, in case they've been changed (sound choice is read on pop-up list change)
        var repeatOnPref = widget.preferenceForKey(prefsKey("repeatSnd"));
        document.getElementById('repeatcheckbox').checked = repeatOnPref;
        repeatSnd = repeatOnPref;
        
        var notifyMeOnPref = widget.preferenceForKey(prefsKey("notifyMe"));
        document.getElementById('notifymecheckbox').checked = notifyMeOnPref;
        notifyMe = notifyMeOnPref;
        
        labelString = widget.preferenceForKey(prefsKey("labelString"));
        document.getElementById('label').value = labelString; // prefs field
        document.getElementById('labelfield').innerText = labelString; // front label field
        
        customTimesUpMessageString = widget.preferenceForKey(prefsKey("customTimesUpMessageString"));
        document.getElementById("customMsgTextField").value = customTimesUpMessageString;
    }
    else {
        var prefSeconds = widget.preferenceForKey(prefsKey("lastSelectedSeconds"));
        var prefMinutes = widget.preferenceForKey(prefsKey("lastSelectedMinutes"));
        var prefHours = widget.preferenceForKey(prefsKey("lastSelectedHours"));
        
        // if we have prefs - populate the txt fields
        if (prefSeconds && prefSeconds.length > 0 ) {
        
            document.getElementById('countDownFromSeconds').value = prefSeconds;
            currentSecondsRound = prefSeconds;
            document.getElementById('countDownFromMinutes').value = prefMinutes;
            currentMinutesRound = prefMinutes;
            document.getElementById('countDownFromHours').value = prefHours;
            currentHoursRound = prefHours;            
         
            renderString(); // send output

            // if values are a popup default - set popup to value
            if (prefSeconds == "00" || prefSeconds == "05"  || prefSeconds == "10" || prefSeconds == "15"
                || prefSeconds == "20" || prefSeconds == "25" || prefSeconds == "30" || prefSeconds == "35"
                || prefSeconds == "40" || prefSeconds == "45" || prefSeconds == "50" || prefSeconds == "55") {
                document.getElementById("countDownFromSecondsPopup").value = prefSeconds;
            } // set closest value
            else if (prefSeconds > 0 && prefSeconds < 5) {
            document.getElementById("countDownFromSecondsPopup").value = "00";}
            else if (prefSeconds > 5 && prefSeconds < 10) {
            document.getElementById("countDownFromSecondsPopup").value = "05";}
            else if (prefSeconds > 10 && prefSeconds < 15) {
            document.getElementById("countDownFromSecondsPopup").value = "10";}
            else if (prefSeconds > 15 && prefSeconds < 20) {
            document.getElementById("countDownFromSecondsPopup").value = "15";}
            else if (prefSeconds > 20 && prefSeconds < 25) {
            document.getElementById("countDownFromSecondsPopup").value = "20";}
            else if (prefSeconds > 25 && prefSeconds < 30) {
            document.getElementById("countDownFromSecondsPopup").value = "25";}                
            else if (prefSeconds > 30 && prefSeconds < 35) {
            document.getElementById("countDownFromSecondsPopup").value = "30";}
            else if (prefSeconds > 35 && prefSeconds < 40) {
            document.getElementById("countDownFromSecondsPopup").value = "35";}
            else if (prefSeconds > 40 && prefSeconds < 45) {
            document.getElementById("countDownFromSecondsPopup").value = "40";}
            else if (prefSeconds > 45 && prefSeconds < 50) {
            document.getElementById("countDownFromSecondsPopup").value = "45";}                
            else if (prefSeconds > 50 && prefSeconds < 55) {
            document.getElementById("countDownFromSecondsPopup").value = "50";}
            else if (prefSeconds > 55 && prefSeconds < 60) {
            document.getElementById("countDownFromSecondsPopup").value = "55";}                                

            if (prefMinutes == "00" || prefMinutes == "01"  || prefMinutes == "02" || prefMinutes == "03"
                || prefMinutes == "04" || prefMinutes == "05" || prefMinutes == "10" || prefMinutes == "15"
                || prefMinutes == "20" || prefMinutes == "25" || prefMinutes == "30" || prefMinutes == "35"
                || prefMinutes == "40" || prefMinutes == "45" || prefMinutes == "50" || prefMinutes == "55") {
                document.getElementById("countDownFromMinutesPopup").value = prefMinutes;
            }
            else if (prefMinutes > 5 && prefMinutes < 10) {
            document.getElementById("countDownFromMinutesPopup").value = "05";}
            else if (prefMinutes > 10 && prefMinutes < 15) {
            document.getElementById("countDownFromMinutesPopup").value = "10";}
            else if (prefMinutes > 15 && prefMinutes < 20) {
            document.getElementById("countDownFromMinutesPopup").value = "15";}
            else if (prefMinutes > 20 && prefMinutes < 25) {
            document.getElementById("countDownFromMinutesPopup").value = "20";}
            else if (prefMinutes > 25 && prefMinutes < 30) {
            document.getElementById("countDownFromMinutesPopup").value = "25";}                
            else if (prefMinutes > 30 && prefMinutes < 35) {
            document.getElementById("countDownFromMinutesPopup").value = "30";}
            else if (prefMinutes > 35 && prefMinutes < 40) {
            document.getElementById("countDownFromMinutesPopup").value = "35";}
            else if (prefMinutes > 40 && prefMinutes < 45) {
            document.getElementById("countDownFromMinutesPopup").value = "40";}
            else if (prefMinutes > 45 && prefMinutes < 50) {
            document.getElementById("countDownFromMinutesPopup").value = "45";}                
            else if (prefMinutes > 50 && prefMinutes < 55) {
            document.getElementById("countDownFromMinutesPopup").value = "50";}
            else if (prefMinutes > 55 && prefMinutes < 60) {
            document.getElementById("countDownFromMinutesPopup").value = "55";}   
            
            if (prefHours == "00" || prefHours == "01"  || prefHours == "02" || prefHours == "03"
                || prefHours == "04" || prefHours == "05" || prefHours == "06" || prefHours == "07" || prefHours == "08"
                || prefHours == "09" || prefHours == "10" || prefHours == "11" || prefHours == "12" ) {
                document.getElementById("countDownFromHoursPopup").value = prefHours;
            }
            else if (prefHours > 12 && prefHours <= 99) {
            document.getElementById("countDownFromHoursPopup").value = "12"; }
            
            // get notification prefs
            var soundOnPref = widget.preferenceForKey(prefsKey("soundOn"));
            if (soundOnPref) { showSndRepeatDiv(); }
                
            var repeatOnPref = widget.preferenceForKey(prefsKey("repeatSnd"));
            document.getElementById('repeatcheckbox').checked = repeatOnPref;
            repeatSnd = repeatOnPref;
            
            var notifyMeOnPref = widget.preferenceForKey(prefsKey("notifyMe"));
            document.getElementById('notifymecheckbox').checked = notifyMeOnPref;
            notifyMe = notifyMeOnPref;
            
            // label
            labelString = widget.preferenceForKey(prefsKey("labelString"));
            document.getElementById('label').value = labelString; // label field back
            document.getElementById('labelfield').innerText = labelString; // label field front
            
            // customMsgString
            customTimesUpMessageString = widget.preferenceForKey(prefsKey("customTimesUpMessageString"));
            document.getElementById("customMsgTextField").value = customTimesUpMessageString;
                        
            // sound choice
            var sndSelectionString = widget.preferenceForKey(prefsKey("soundString"));
            
            debugAlerts('sndSelectionString (readPrefs) = ' +sndSelectionString );
            
            if (sndSelectionString == "No sound") {
                document.getElementById("sndPopup").value = 0;
                document.getElementById ("sndPopupText").innerText = getLocalizedString('noSound');
                
                soundOn = false;
                hideSndRepeatDiv();
            }
            else if (sndSelectionString == "3-2-1 Bell") {
                document.getElementById("sndPopup").value = 1;
                document.getElementById ("sndPopupText").innerText = getLocalizedString('3-2-1 Bell');
                pathToSound = pathArray[1];
                soundOn = true;
                showSndRepeatDiv();
                
                debugAlerts("3-2-1 Bell chosen");
            }
            else { // find selected sound string
                for (var i = 0; i <= soundArray.length; i++)  {
                    if (soundArray[i] == sndSelectionString) {    
                        document.getElementById("sndPopup").value = i;
                        document.getElementById ("sndPopupText").innerText = sndSelectionString;
                        
                        pathToSound = pathArray[i];
                        if (i != 1) {
                            pathToSound = "file://" + pathToSound; 
                        }
                        soundOn = true;
                        showSndRepeatDiv();
                        
                        break;
                    }
                    else if (i == soundArray.length) { // if we're at the last item and still no match...
                        document.getElementById ("sndPopupText").innerText = getLocalizedString('noSound');
                        document.getElementById("sndPopup").value = 0;
                        widget.setPreferenceForKey("No sound",prefsKey("soundString")); 
                        soundOn = false;
                        hideSndRepeatDiv();
                        alert("Users sound not available");
                    }
                }
            } // end sound prefs section
        }
            
            
        // IF NO PREFS EXIST    
        else { // show startup txt
            document.getElementById('Clock').style.opacity = '0.0';
            document.getElementById('Clock').style.display = 'block';
            scaleMessageSize(1);
            document.getElementById('StartStopButton').className = 'startstoptoggleButtonStartOff';
                                    
            // make default settings on back
            widget.setPreferenceForKey(110,prefsKey("usersFrontHeight"));
            widget.setPreferenceForKey(290,prefsKey("usersFrontWidth"));
            soundOn = true; // turn sound on as a default
            widget.setPreferenceForKey(soundOn,prefsKey("soundOn"));
            toggleNotifyme(); // turn on and make pref
            showSndRepeatDiv();
            toggleRepeat();
            widget.setPreferenceForKey("3-2-1 Bell",prefsKey("soundString"));
            // set popup + popuptext to correct values
            document.getElementById ("sndPopupText").innerText = getLocalizedString('3-2-1 Bell');
            document.getElementById("sndPopup").value = 1;
            
            debugAlerts('No Prefs (readPrefs) = using defaults ');
        }
    }
    debugAlerts('prefs read');
}

//- mark ## TRANSITIONS
function rollup(size, end_func) {
    sizenow = document.getElementById("back").offsetHeight;
    incr = 10;
    
    var dH = Math.abs(sizenow - size);
    
    if (dH > 50) { incr = 20; } 
    else if (dH > 20) { incr = 10; }
    else if (dH > 10) { incr = 5; }
    else if (dH > 5) { incr = 2; }
    else if (dH < 6) { incr = 1; }

    if (sizenow > size) { // closing back
        document.getElementById("back").style.height = (sizenow - incr) + "px";
        setTimeout("rollup("+size+",'"+end_func+"')",0);
    } 
    else if (sizenow < size) { // opening back
        document.getElementById("back").style.height = (sizenow + incr) + "px";
        setTimeout("rollup("+size+",'"+end_func+"')",0);
    }
    else { // final size. eval Callback
        window.resizeTo(290, size + 1);
        if (end_func != null) eval(end_func);
    }
}

function rectHandler( rectAnimation, currentRect, startingRect, finishingRect ) {
	document.getElementById("middle").style.height = (currentRect.bottom-16);
	document.getElementById("bottom").style.top = (currentRect.bottom-16);
	window.resizeTo(currentRect.right, currentRect.bottom);	
}

//- mark ## goto back sequence
function gotoPrefs() {
    editingFlag = "";
    writePrefs();
	// save users window size to return to
	usersFrontHeight = window.innerHeight;
	usersFrontWidth = window.innerWidth;
		
	if (usersFrontWidth != 290) { // if not default size - do resize
	
        document.getElementById('Clock').style.display = 'none';
        document.getElementById('dummyClock').style.display = 'none';
        
        // Two AppleRect objects store the starting and finshing rectangle sizes
        var startingRect = new AppleRect (0, 0, window.innerWidth, window.innerHeight);
        var finishingRect = new AppleRect (0, 0, 290, 110);
        // The RectAnimation specifies the range of values and the handler to call at the animator's interval
        var currentRectAnimation = new AppleRectAnimation( startingRect, finishingRect, rectHandler );
        // The Animator is the timer for the animation
        var currentAnimator = new AppleAnimator (300, 13);
        // Associate the animator and animation
        currentAnimator.addAnimation(currentRectAnimation);
        // Set a handler to be called when the animation is done (in this case, flip the widget to its back)
        currentAnimator.oncomplete = widgetTransitionToBack;    
        // Once everything is set up, start the animation
        currentAnimator.start();
	}
	else { // go straight to back
        document.getElementById('Clock').style.display = 'none';
        document.getElementById('dummyClock').style.display = 'none';
        widgetTransitionToBack();
	}
	customMsgFlag = 0; // turn off customMsgFlag
}

// used on startup/reload/fliptofront
function resizeFrontToUsersDefaultSize() {     
    debugAlerts('resizeFrontToUsersDefaultSize');
    usersFrontHeight = widget.preferenceForKey(prefsKey("usersFrontHeight"));
    usersFrontWidth = widget.preferenceForKey(prefsKey("usersFrontWidth"));    
    
    // if not default size - do resize
    if (usersFrontWidth != null && usersFrontWidth != 290) {
        document.getElementById('Clock').style.display = 'none';
	
        var finishingRect = new AppleRect (0, 0, usersFrontWidth, usersFrontHeight);
        var startingRect = new AppleRect (0, 0, 290, 110);
        
        var currentRectAnimation = new AppleRectAnimation( startingRect, finishingRect, rectHandler );
        var currentAnimator = new AppleAnimator (300, 13);
        currentAnimator.addAnimation(currentRectAnimation);
        currentAnimator.oncomplete = scaleFontSize;    
    
        currentAnimator.start();
    }
    else {
        scaleFontSize();
    }
}

function widgetTransitionToBack() { // standard widget transition

    var front = document.getElementById("front");
    var back = document.getElementById("back");
 
	if (window.widget) {
		widget.prepareForTransition("ToBack");
 	}
		
    front.style.display="none";
    back.style.display="block";
 
    if (window.widget) {
        setTimeout ('widget.performTransition();', 0 );
		widget.setCloseBoxOffset(3,3);
    }
    // delay for flip to finish - would use callback from performTransition() if there was one
    // see below for a 10.4.3 (and later) callback - not currently using it here though
    // http://lists.apple.com/archives/dashboard-dev/2005/Nov/msg00036.html
    setTimeout("resizeBackDiv(290, null)",750);
}

//- mark ## goto front sequence
function finishedWithPrefs() { // called by the done button
    resizeBackDiv(110, "widgetTransitionToFront();");
}

function resizeBackDiv(size, end_func) { 
//debugAlerts("resizeBackDiv");
    document.getElementById("soundEmbed").innerHTML = ""; // make sure we're not still playing any snd's
    
    // open back
    if (document.getElementById("back").offsetHeight < size) {
        window.resizeTo(290, size);
        rollup(size, end_func);
        document.getElementById("textfieldstitle").style.display = "block"; // show hidden elements
        document.getElementById("notificationstitle").style.display = "block";
        document.getElementById("instructions").style.display = "block";
        document.getElementById("bringtofront").style.display = "block";
        document.getElementById("notifymecheckbox").style.opacity = "1.0";
        document.getElementById('countDownFromHours').focus();
        
        
    } 
    // close back
    else {
        writePrefs();
        renderPrefsValues();
                
        document.getElementById("textfieldstitle").style.display = "none"; // hide the still visible top bits
        document.getElementById("notificationstitle").style.display = "none";
        document.getElementById("instructions").style.display = "none";
        document.getElementById("bringtofront").style.display = "none";
        document.getElementById("notifymecheckbox").style.opacity = "0.0";
        
        rollup(size, end_func); 
    }
}

function widgetTransitionToFront() { // called after resizeBackDiv, performs widget transition

    var front = document.getElementById("front");
    var back = document.getElementById("back");
	
	if (window.widget) {
		widget.prepareForTransition("ToFront");
 	}

    back.style.display="none";
    front.style.display="block";
    	
    if (window.widget) {
        setTimeout ('widget.performTransition();', 0);
		widget.setCloseBoxOffset(3,3);
	}
	
	setTimeout("scaleFrontToUsersSize()", 750); // delay for front to flip
}

function scaleFrontToUsersSize() { 
    if (usersFrontWidth != 290) {
    
        var startingRect = new AppleRect (0, 0, 290, 110);
        var finishingRect = new AppleRect (0, 0, usersFrontWidth, usersFrontHeight);
        
        var currentRectAnimation = new AppleRectAnimation( startingRect, finishingRect, rectHandler );
        var currentAnimator = new AppleAnimator (300, 13);
        currentAnimator.addAnimation(currentRectAnimation);
        currentAnimator.oncomplete = scaleFontSize;
        currentAnimator.start(); 
    }
    else {
        scaleFontSize();
    }
}

//- mark ## SOUND
function setSilenceSoundPath() {
    var documentPath = document.URL;
    var pathComponents = documentPath.split("/");
    var documentName = pathComponents[pathComponents.length - 1];
    pathToSilence = documentPath.substring(0, (documentPath.length - documentName.length)) + "silence.aif";
}

function alertSound(repeat) {
    var soundEmbedString = "";
    
    debugAlerts('alertSound repeat ='+repeat);

    if (soundOn) { 
        document.getElementById("soundEmbed").innerHTML = "";
        
        if (!repeat) {
            soundEmbedString  = "<embed src='"+ pathToSound + "' hidden='true' autostart='true' enablejavascript='true'>";
        }       
        else {
            if (pathToSound == "simple_bell.aif") {
                soundEmbedString  = "<embed src='"+ pathToSound + "' hidden='true' autostart='true' enablejavascript='true' loop='true' >";
            }
            else {
                soundEmbedString  = "<embed src='"+ pathToSound + "' hidden='true' autostart='true' enablejavascript='true' QTNext1='<"+ pathToSilence +">T<myself>' QTNext2=GoTo0 >";
            }       
        }
        
        document.getElementById("soundEmbed").innerHTML = soundEmbedString;
        
        debugAlerts('soundEmbedString ='+soundEmbedString);
    }

    scaleMessageSize(2);
}

function popupSounds(selection) {	

    pathToSound="";
	var sndSelectionValue = selection.value;	

        if (sndSelectionValue == 0) { //none
            soundOn = false;
            hideSndRepeatDiv();
            document.getElementById ("sndPopupText").innerText = getLocalizedString('noSound');
            
            widget.setPreferenceForKey("No sound",prefsKey("soundString"));
        }
        else { // load snd & change label
            soundOn = true;
            pathToSound = pathArray[sndSelectionValue];
            if (sndSelectionValue != 1) {
                pathToSound= "file://" + pathToSound; 
            }
                        
            showSndRepeatDiv();
            document.getElementById("soundEmbed").innerHTML = "<embed src='"+ pathToSound + "' hidden='true' autostart='true' enablejavascript='true' >"; // play sound         
     
            // write sndstring as a pref
            var sndSelectionString = document.getElementById ("sndPopup").options[sndSelectionValue].text;
            widget.setPreferenceForKey(sndSelectionString,prefsKey("soundString"));
            document.getElementById ("sndPopupText").innerText = sndSelectionString;
            }   
    
        widget.setPreferenceForKey(soundOn,prefsKey("soundOn")); // store as pref
}

function populateSoundsPopup() {	
    getUser();
	var outputString;
	
    var tempSoundArray1 = new Array;
    var tempPathArray1 = new Array;
	
    tempSoundArray1[0] = getLocalizedString("noSound");
    tempSoundArray1[1] = getLocalizedString("3-2-1 Bell");
    tempPathArray1[0] = "";
    tempPathArray1[1] = "simple_bell.aif";
    
	var systemLibraryPath = "/System/Library/Sounds/";
	var mainLibraryPath = "/Library/Sounds/";
	var userLibraryPath = "/Users/"+currentUser+"/Library/Sounds/";
	
    var namesPipe = " | grep -v \"/\" | sed -e 's/\.[a-zA-Z0-9]*$//'";	
	var pathsPipe   = " | grep -v \"/\" | awk '{print";

	var systemPathToTempFile = "/private/var/tmp/soundPaths.txt";	
	var unixPathToTempFile = "/private/var/tmp/soundPaths.txt";
	
	var getNames=	"ls -p " + userLibraryPath + namesPipe + "; ls " + mainLibraryPath + namesPipe + "; ls " + systemLibraryPath + namesPipe;

	var tempPath1 = "ls -p " + userLibraryPath + pathsPipe + '"' + userLibraryPath + '"' + "$0}'  > "+unixPathToTempFile+"";	
	var paths = widget.system(tempPath1,null).outputString;
	
	var tempPath2 = "ls " + mainLibraryPath + pathsPipe + '"' + mainLibraryPath + '"' + "$0}'  >> "+unixPathToTempFile+"";
	paths = widget.system(tempPath2,null).outputString;
	
	var tempPath3 = "ls " + systemLibraryPath + pathsPipe + '"' + systemLibraryPath + '"' + "$0}'  >> "+unixPathToTempFile+"";
	paths = widget.system(tempPath3,null).outputString;
	
	paths = readInFile(systemPathToTempFile);
	widget.system("/bin/rm -f "+unixPathToTempFile+"", null);
	
	if (paths == null) {
        alert("Unable to read sounds. Continuing with no sound.");        
        break;
	} 
	
    var names = widget.system(getNames,null).outputString;	
		
    var tempSoundArray2 = new Array;
    var tempPathArray2 = new Array;

    tempSoundArray2 = names.split('\n');
    tempPathArray2 =  paths.split('\n');
        
    soundArray = tempSoundArray1.concat(tempSoundArray2);
    pathArray = tempPathArray1.concat(tempPathArray2);
    
    for (i=0; i< soundArray.length-1; i++) {
        var element = document.createElement("option");
        element.innerText = soundArray[i];
        element.setAttribute("value",i);
        document.getElementById ("sndPopup").appendChild(element);     		
     }
}

function readInFile(filename) { 
    req = new XMLHttpRequest(); 
    req.open("GET", filename ,false); 
    req.send(null); 
    response = req.responseText; 
    if (response) { 
        return response; 
    } 
    return null 
}

//- mark ## VERSION & UPDATE
function getThisVersion() {
var internalContent, internalVersion;
var xmlInternal;
var keys, vals;

    // get internal version
    xmlInternal = new XMLHttpRequest(); 
    xmlInternal.open("GET", "Info.plist", false);
    xmlInternal.send(null);
    
    internalContent = xmlInternal.responseXML;
    keys = internalContent.getElementsByTagName("key");
    vals = internalContent.getElementsByTagName("string"); 
    
    for (var i=0; i < keys.length; i++) { 
        if (keys[i].firstChild.data == "CFBundleVersion") { 
            internalVersion = vals[i].firstChild.data;
            debugAlerts('internalVersion='+internalVersion);
            // put internal version on prefs back
            document.getElementById("version").innerHTML = "v" + internalVersion;
            break; 
        }
    }
    
    return internalVersion;        
}

function updateCheck() {
    // get external Version
    xmlExternal = new XMLHttpRequest();
    xmlExternal.onreadystatechange = compareVersion;
    xmlExternal.open("GET", "http://www.baldgeeks.com/Versions/Versions.xml", true);
    xmlExternal.setRequestHeader("Cache-Control", "no-cache");
    xmlExternal.send(null);
}

function compareVersion() {
var externalContent, externalVersion;
var keys, vals;

    if (xmlExternal.readyState == 4) {
		if (xmlExternal.status == 200) {
            externalContent = xmlExternal.responseXML;
            keys = externalContent.getElementsByTagName("key");
            vals = externalContent.getElementsByTagName("string");
    
            for (var i=0; i < keys.length; i++) {
                if (keys[i].firstChild.data == "3-2-1.wdgt") {
                    externalVersion = vals[i].firstChild.data;
                    debugAlerts('externalVersion='+externalVersion);
                    break;
                }
            }
                        
    
            // compare internal to external
            if (externalVersion > getThisVersion()) {
                
                windowWidth = window.innerWidth;
                
                debugAlerts('new version available');
                // display sml or lrg update bevel
                if (windowWidth < 288) {
                    document.getElementById('update').innerHTML = "<table width='100%' height='100%' border='0' cellpadding='0' cellspacing='0'><tr><td align='center' valign='middle'><table width='109' height='36' border='0' cellpadding='0' cellspacing='0'><tr><td width='22' height='20'><img src='images/update/smlUpdateP1.png' width='22' height='20' onclick='dismissUpdate();' style='cursor:pointer;'></td><td width='87' height='36' rowspan='2'><a href='javascript:openURL(\"http://www.baldgeeks.com/3-2-1.htm\");'><img id='smlUpdateP2' src='images/update/smlUpdateP2.png' width='87' height='36' onmouseover='updatesmlover();' onmouseout='updatesmloff();'></a></td></tr><tr><td width='22' height='16'><img src='images/update/smlUpdateP3.png' width='22' height='16' alt=''></td></tr></table></td></tr></table>";
                }
                else {
                    document.getElementById('update').innerHTML = "<table width='100%' height='100%' border='0' cellpadding='0' cellspacing='0'><tr><td align='center' valign='middle'><table width='257' height='34' border='0' cellpadding='0' cellspacing='0'><tr><td width='34' height='34'><img src='images/update/lrgUpdateP1.png' width='34' height='34' onclick='dismissUpdate();' style='cursor:pointer;'></td><td width='223' height='34'><a href='javascript:openURL(\"http://www.baldgeeks.com/3-2-1.htm\");'><img id='lrgUpdateP2' src='images/update/lrgUpdateP2.png' width='223' height='34' onmouseover='updateover();' onmouseout='updateoff();'></a></td></tr></table></td></tr></table>";
                }

                document.getElementById('update').style.opacity = '0.0';
                document.getElementById('update').style.display = 'block';
                fadeUpdateGraphic();
            }
        }
        else {
            // Couldn't connect to update server
            // manually add v on prefs
            getThisVersion();
        }
    }
}

var animationUpdateGraphic = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0, firstElement:null, timer:null};

function fadeUpdateGraphic() {
    var starttime = (new Date).getTime() - 50;
    animationUpdateGraphic.duration = 1050;
    animationUpdateGraphic.starttime = starttime;
    animationUpdateGraphic.firstElement = document.getElementById ('update');
    animationUpdateGraphic.timer = setInterval ("doUpdateGraphicFade(animationUpdateGraphic);", 50);
    animationUpdateGraphic.from = animationUpdateGraphic.now;
    animationUpdateGraphic.to = 1.0;
    doUpdateGraphicFade(animationUpdateGraphic);
}

function doUpdateGraphicFade(updateGraphic) {
var T;
var ease;
var time = (new Date).getTime();

    T = limit_3(time-updateGraphic.starttime, 0, updateGraphic.duration);

    if (T >= updateGraphic.duration) {
        clearInterval (updateGraphic.timer);
        updateGraphic.timer = null;
        updateGraphic.now = updateGraphic.to;
        // at end of fade disable update div
        if (animationUpdateGraphic.to == 0.0) {
            document.getElementById('update').style.display = 'none';
        }
    }
    else {
        ease = 0.5 - (0.5 * Math.cos(Math.PI * T / updateGraphic.duration));
        updateGraphic.now = computeNextFloat (updateGraphic.from, updateGraphic.to, ease);
    }
    updateGraphic.firstElement.style.opacity = updateGraphic.now;
}

function dismissUpdate() {        
    var starttime = (new Date).getTime() - 50;
    animationUpdateGraphic.duration = 350;
    animationUpdateGraphic.starttime = starttime;
    animationUpdateGraphic.firstElement = document.getElementById ('update');
    animationUpdateGraphic.timer = setInterval ("doUpdateGraphicFade(animationUpdateGraphic);", 50);
    animationUpdateGraphic.from = animationUpdateGraphic.now;
    animationUpdateGraphic.to = 0.0;
    doUpdateGraphicFade(animationUpdateGraphic);
}

function limit_3 (a, b, c) {
	return a < b ? b : (a > c ? c : a);
}

function computeNextFloat (from, to, ease) {
	return from + (to - from) * ease;
}

//- mark ## UTILITIES
if (window.widget) {
	widget.onhide = onhide;
	widget.onshow = onshow;
    widget.onremove = onremove;
}

function onshow() {
    dashboardShown = true;	
}

function onhide() {
    writePrefs();
    dashboardShown = false;
}

function onremove () {
    if (window.widget) { // kill prefs
    widget.setPreferenceForKey(null, prefsKey("lastSelectedHours"));
    widget.setPreferenceForKey(null, prefsKey("lastSelectedMinutes"));
    widget.setPreferenceForKey(null, prefsKey("lastSelectedSeconds"));		
    widget.setPreferenceForKey(null, prefsKey("soundOn"));
    widget.setPreferenceForKey(null, prefsKey("repeatSnd"));
    widget.setPreferenceForKey(null, prefsKey("notifyMe"));
    widget.setPreferenceForKey(null, prefsKey("soundNumber"));
    widget.setPreferenceForKey(null, prefsKey("soundString"));
    widget.setPreferenceForKey(null, prefsKey("labelString"));
    widget.setPreferenceForKey(null, prefsKey("customTimesUpMessageString"));
    widget.setPreferenceForKey(null, prefsKey("usersFrontHeight"));
	widget.setPreferenceForKey(null, prefsKey("usersFrontWidth"));
    }
}

function mouseDown(event) {
    debugAlerts('resizing started');
    canShowButtonLabels = 0; // turn off buttonlabels during drag
    
    if (lapFlag == 1) {
        document.getElementById('Laptime').style.display = 'none';
    }
    
    document.addEventListener("mousemove", mouseMove, true);
    document.addEventListener("mouseup", mouseUp, true);
 
    growboxInset = {x:(window.innerWidth - event.x), y:(window.innerHeight - event.y)};
   
    document.getElementById('Clock').style.display = 'none';
    document.getElementById("dummyClock").innerHTML = "<img src='images/xxblured.png' width='100%' />"
    document.getElementById('dummyClock').style.opacity = '1.0';
    document.getElementById('dummyClock').style.display = 'block';
    editingFlag = "";
    
    event.stopPropagation();
    event.preventDefault();
}

function mouseMove(event) {
    // checks if the reported event data is legit or not
	if((event.x == -1 ) ) {
        //debugAlerts('mouseMove event data invalid');
        break;
	}

	var x = event.x + growboxInset.x;
    
    if(x <= 120) {	// minimum width
		x = 120;
	}
    
    // equation of a line - used to plot width/height ratio as widget scales
    // y = slope of line * x + yIntercept
    var y = (0.25 * x) + 38;  

	document.getElementById("middle").style.height = (y-16);
	document.getElementById("bottom").style.top = (y-16);
	
    window.resizeTo(x,y);
    event.stopPropagation();
    event.preventDefault();
}
 
function mouseUp(event) {
    debugAlerts('resizing finished');
    document.removeEventListener("mousemove", mouseMove, true);
    document.removeEventListener("mouseup", mouseUp, true);
    
    event.stopPropagation();
    event.preventDefault();
    
    usersFrontHeight = window.innerHeight;
	usersFrontWidth = window.innerWidth;
		
    // save new width & height pref
    widget.setPreferenceForKey(usersFrontHeight,prefsKey("usersFrontHeight"));
    widget.setPreferenceForKey(usersFrontWidth,prefsKey("usersFrontWidth"));
    
    document.getElementById('dummyClock').style.display = 'none';
    
    if (customMsgFlag == 1) {
        scaleMessageSize(1);
    }
    else if (customMsgFlag == 2) {
        scaleMessageSize(2);
    }
    else {
        scaleFontSize();
    }    
    hideLabels(); // free up any stuck labels
}

function getUser() {
    if (window.widget) {
		currentUser = widget.system("/usr/bin/id -un",null).outputString;
		currentUser = currentUser.replace(trimRegExp,"");
		currentUser = currentUser.replace(trimMoreRegExp,"");
	}
}

function focusOnMe(element) {
    debugAlerts(' focusOnMe');
    document.getElementById(element).setAttribute("style", "border:1px solid white;");    
}

function blurMe(element) {
    debugAlerts(' blurMe');
    document.getElementById(element).setAttribute("style", "border:1px solid black;"); 
}

function isInteger(n) {
    return (Math.floor(n) == n);
}

function getLocalizedString(key) {
    try {
        var ret = localizedStrings[key];
        if (ret === undefined)
            ret = key;
        return ret;
    } catch (ex) {}
    return key;
}

function openURL(url) {
    if (window.widget) widget.openURL(url);
}

function bringDashboardToFront() {
	if (!dashboardShown) {
        if (notifyMe) {            
            widget.system("/usr/bin/open /Applications/Dashboard.app",null);
            dashboardShown = true;
        }
	}										
}
