var localizedStrings = new Array;

localizedStrings["StartUpTxt"] = "Naciśnij tu by ustawić czas.";

localizedStrings["clockClickToReset"] = "Naciśnij by wyzerować.";
localizedStrings["null"] = "";
localizedStrings["custommsgtitle"] = "Tekst wiadomości powiadamiającej:";
localizedStrings["timesupmessage"] = "Czas minął!";
  
localizedStrings["Laptime"] = "Międzyczas";
localizedStrings["Start"] = "Start";
localizedStrings["Stop"] = "Stop";
localizedStrings["Lap on"] = "Pokaż międzyczas";
localizedStrings["Lap off"] = "Wyłącz międzyczas";
localizedStrings["Reset"] = "Wyzeruj";

localizedStrings["textfieldstitle"] = "Odliczanie od:";
localizedStrings["notificationstitle"] = "Powiadomienia:";
localizedStrings["labeltitle"] = "Etykieta:";
localizedStrings["labelfieldinstructions"] = "Wpisz własną etykietę.";
localizedStrings["customMsgTextFieldTitleTag"] = "Wpisz swój tekst wiadomości powiadamiającej.";
localizedStrings["bringtofront"] = "<span title='Wyświetl dashboard jeżeli jest schowany.'>Wyświetl dashboard</span>";
localizedStrings["repeatcheckboxtext"] = "<span title='Powtarzaj dźwięk aż do jego wyłączenia.'>Powtarzaj dźwięk</span>";
localizedStrings["instructions"] = "Wpisz godziny, minuty i sekundy do pól lub wybierz je z list.";
localizedStrings["sndPopup"] = "Wybierz dźwięk z listy.";
localizedStrings["noSound"] = "Bez dźwięku";
localizedStrings["3-2-1 Bell"] = "Dzwonek 3-2-1";
localizedStrings["Done"] = "Gotowe";
localizedStrings["helpButtonTitleTag"] = "Pomoc 3-2-1";

localizedStrings["laptimeLabelCutOffPoint"] = 357;
localizedStrings["buttonLabelsCutOffPoint"] = 222;