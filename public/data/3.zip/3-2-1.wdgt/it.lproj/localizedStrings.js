var localizedStrings = new Array;

localizedStrings["StartUpTxt"] = "Click qui per impostare il tempo.";

localizedStrings["clockClickToReset"] = "Click per ricominciare.";
localizedStrings["null"] = "";
localizedStrings["custommsgtitle"] = "Messaggio d'avviso:";
localizedStrings["timesupmessage"] = "Fine del tempo!";
  
localizedStrings["Laptime"] = "TEMPO DEL GIRO";
localizedStrings["Start"] = "Inizio";
localizedStrings["Stop"] = "Stop";
localizedStrings["Lap on"] = "Giro on";
localizedStrings["Lap off"] = "Giro off";
localizedStrings["Reset"] = "Ricomincia";

localizedStrings["textfieldstitle"] = "Conto alla rovescia:";
localizedStrings["notificationstitle"] = "Avvisi:";
localizedStrings["labeltitle"] = "Etichetta:";
localizedStrings["labelfieldinstructions"] = "Inserisci la tua etichetta.";
localizedStrings["customMsgTextFieldTitleTag"] = "Inserisci il tuo messaggio d'avviso.";
localizedStrings["bringtofront"] = "<span title='Rendilo attivo con Dashboard nascosto.'>Porta in primo piano</span>";
localizedStrings["repeatcheckboxtext"] = "<span title='Ripete il suono finchè non si interviene.'>Ripeti il suono</span>";
localizedStrings["instructions"] = "Inserisci ore, minuti e secondi negli spazi, oppure usa le liste di selezione rapida sottostanti.";
localizedStrings["sndPopup"] = "Seleziona un suono dalla lista.";
localizedStrings["noSound"] = "Nessun suono";
localizedStrings["3-2-1 Bell"] = "Campanello 3-2-1";
localizedStrings["Done"] = "Fatto";
localizedStrings["helpButtonTitleTag"] = "Aiuto 3-2-1";

localizedStrings["laptimeLabelCutOffPoint"] = 358;
localizedStrings["buttonLabelsCutOffPoint"] = 179;