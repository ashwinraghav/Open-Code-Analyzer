var localizedStrings = new Array;

localizedStrings["StartUpTxt"] = "Click here to set time.";

localizedStrings["clockClickToReset"] = "Click to reset.";
localizedStrings["null"] = "";
localizedStrings["custommsgtitle"] = "Alert message:";
localizedStrings["timesupmessage"] = "Time's Up!";
  
localizedStrings["Laptime"] = "LAP TIME";
localizedStrings["Start"] = "Start";
localizedStrings["Stop"] = "Stop";
localizedStrings["Lap on"] = "Lap on";
localizedStrings["Lap off"] = "Lap off";
localizedStrings["Reset"] = "Reset";

localizedStrings["textfieldstitle"] = "Countdown from:";
localizedStrings["notificationstitle"] = "Notifications:";
localizedStrings["labeltitle"] = "Label:";
localizedStrings["labelfieldinstructions"] = "Enter your own label.";
localizedStrings["customMsgTextFieldTitleTag"] = "Enter your own alert message.";
localizedStrings["bringtofront"] = "<span title='When Dashboard is hidden make it active.'>Bring to front</span>";
localizedStrings["repeatcheckboxtext"] = "<span title='Repeat the alarm sound until stopped.'>Repeat sound</span>";
localizedStrings["instructions"] = "Enter hours, minutes and seconds into the boxes, or use the quicklists below.";
localizedStrings["sndPopup"] = "Select a sound option from the list.";
localizedStrings["noSound"] = "No sound";
localizedStrings["3-2-1 Bell"] = "3-2-1 Bell";
localizedStrings["Done"] = "Done";
localizedStrings["helpButtonTitleTag"] = "3-2-1 Help";

localizedStrings["laptimeLabelCutOffPoint"] = 270;
localizedStrings["buttonLabelsCutOffPoint"] = 155;