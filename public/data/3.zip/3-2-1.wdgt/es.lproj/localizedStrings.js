var localizedStrings = new Array;

localizedStrings["StartUpTxt"] = "Pulsar aquí para poner el tiempo.";

localizedStrings["clockClickToReset"] = "Pulsar para reinicializar.";
localizedStrings["null"] = "";
localizedStrings["custommsgtitle"] = "Mensaje de alerta:";
localizedStrings["timesupmessage"] = "¡Se acabó el tiempo!";

localizedStrings["Laptime"] = "<span style = 'font-size: 15px;line-height:22px;'>TIEMPOS PARCIALES</span>";
localizedStrings["Start"] = "Inicio";
localizedStrings["Stop"] = "Detener";
localizedStrings["Lap on"] = "Empezar vueltas";
localizedStrings["Lap off"] = "Finalizar vueltas";
localizedStrings["Reset"] = "Reinicializar";

localizedStrings["textfieldstitle"] = "Cuenta atrás desde:";
localizedStrings["notificationstitle"] = "Avisos:";
localizedStrings["labeltitle"] = "Etiqueta:";
localizedStrings["labelfieldinstructions"] = "Introduzca su etiqueta.";
localizedStrings["customMsgTextFieldTitleTag"] = "Introduzca su propio mensaje de alerta.";
localizedStrings["bringtofront"] = "<span title='Cuando no aparece el Dashboard, actívalo.'>Traer delante</span>";
localizedStrings["repeatcheckboxtext"] = "<span title='Repetir la alarma hasta que la pares.'>Repetir sonido</span>";
localizedStrings["instructions"] = "Introducir las horas, minutos y segundos en las casillas o utilizar las listas.";
localizedStrings["sndPopup"] = "Elegir una opción de sonido.";
localizedStrings["noSound"] = "Sín sonido";
localizedStrings["3-2-1 Bell"] = "3-2-1 Alarma";
localizedStrings["Done"] = "Salir";
localizedStrings["helpButtonTitleTag"] = "Ayuda 3-2-1";

localizedStrings["laptimeLabelCutOffPoint"] = 380;
localizedStrings["buttonLabelsCutOffPoint"] = 205;